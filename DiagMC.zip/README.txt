Task 2: pi_est.py
Task 3: cdf_inversion.py
Task 4: MCMC_exp.py (not complete, only basics. All missing features are included in the next tasks)
Task 5,6&7: DMC.py and DMC_tests.py for usage/output

The #%% Blocks are Jupyter Cells, intended to be run in an IPython console. VSCode treats them as such.