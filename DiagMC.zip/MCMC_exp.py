#%% MCMC for the exponential distribution
import numpy as np
import matplotlib.pyplot as plt

alpha = 1
n_equ = int(1e4)
n_sam = int(1e6)
n_acc = 0
n_rej = 0
rng = np.random.default_rng()

#function to sample from
def f(x):
    return np.exp(-alpha*x)

#uniform distribution
uni = rng.uniform

#acceptance ratio for Metropolis-Hastings
def acc_ratio(x, x_new):
    return f(x_new)/f(x)

#initial sample
curr = uni(0,5)

#array to store samples
samples = np.zeros(n_sam)

#equilibration
for i in range(n_equ):
    prop = uni(0,5)
    if acc_ratio(curr, prop) > np.random.random():
        curr = prop
        n_acc += 1
    else:
        n_rej += 1

#sampling
for i in range(n_sam):
    prop = uni(0,5)
    if acc_ratio(curr, prop) > np.random.random():
        curr = prop
        n_acc += 1
    else:
        n_rej += 1
    samples[i] = curr

#plotting
print(n_acc/(n_acc + n_rej))
hist, bin_edges = np.histogram(samples, bins=100, density=False)
bin_centers = (bin_edges[:-1] + bin_edges[1:])/2
bin_widths = np.diff(bin_edges)
hist = hist/hist[0]*f(bin_centers[0])
#calculate the norm analytically
norm = (np.exp(-alpha*0) - np.exp(-alpha*5))/alpha
plt.bar(bin_centers, hist, width=bin_widths)
i2 = np.mean(samples**2*norm)
print(i2)

# %%
