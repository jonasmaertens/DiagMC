#%% Inverse transform sampling
# f(x) = exp(-alpha*x)
# F(x) = (1 - exp(-alpha*x))/alpha
# r = F(x)/F(x_max)
# x = -ln(1 - alpha*r*F(x_max))/alpha
import numpy as np
import matplotlib.pyplot as plt

alpha = 1
x_max = 5
n = int(1e8)

def F(x):
    return (1 - np.exp(-alpha*x))/alpha

F_max = F(x_max)

def F_inv(r):
    return -np.log(1 - alpha*r*F_max)/alpha

#generate all samples at once using numpy
r = np.random.random(n)
x = F_inv(r)
hist, bin_edges = np.histogram(x, bins=200, density=True)
hist *= F_max
bin_centers = (bin_edges[:-1] + bin_edges[1:])/2
bin_widths = np.diff(bin_edges)
plt.xlabel("$\\tau$")
plt.ylabel("$Q(\\tau)$")
plt.title("Inverse transform sampling - n = 1e8")
plt.bar(bin_centers, hist, width=bin_widths, label="$\\rho(\\tau)\\cdot Norm$")
x_ana = np.linspace(0, x_max, 1000)
plt.plot(x_ana, np.exp(-alpha*x_ana), 'r', label="$Q_{exact}(\\tau)$")
plt.legend()
plt.savefig("./Latex/images/cdf_inversion2.png", dpi=300)
print("I1 exact: 1-6*exp(-5) = 0.9595723")
print(f"I1 mean: { np.mean(x)*F_max:.6f}")
print(f"I1 std: {np.std(x)*F_max/np.sqrt(n):.3e}")
print("I2 exact: 2-37*exp(-5) = 1.750696")
print(f"I2 mean: {np.mean(x**2)*F_max:.6f}")
print(f"I2 std: {np.std(x**2)*F_max/np.sqrt(n):.3e}")

# %%
