# %% Area Method
import numpy as np
import matplotlib.pyplot as plt


def area_method(n, plot=False):
    n_in = 0
    estimates_n = np.array([], dtype=int)
    estimates_area = np.array([])
    for i in range(n):
        # generate random numbers between 0 and 1
        x = np.random.random()
        y = np.random.random()
        # check if the point is in the circle
        if x**2 + y**2 <= 1:
            n_in += 1
        # every 10000 points, calculate the area
        if plot:
            if i % (int(n / 100000)) == 0 and i > 1000000:
                estimates_n = np.append(estimates_n, i + 1)
                estimates_area = np.append(estimates_area, 4 * n_in / (i + 1))
    if plot:
        plt.xlabel("n")
        plt.title("Area Method - Convergence")
        plt.ylabel("Pi Estimate")
        plt.plot(estimates_n, estimates_area, label="Estimate")
        plt.axhline(y=np.pi, color="k", label="$\\pi$")
        plt.legend()
        plt.savefig("./Latex/images/area_method_convergence2.png", dpi=300)
    return 4 * n_in / n


def area_method_fast(n):
    x = np.random.random(n)
    y = np.random.random(n)
    n_in = np.sum(x**2 + y**2 <= 1)
    return 4 * n_in / n

#%%
area_method(int(1e8), plot=True)

#%%
pis = np.zeros(10000)
for i in range(10000):
    pis[i] = area_method_fast(int(1e6))
std = np.std(pis)
mean = np.mean(pis)
plt.ylabel("n")
plt.xlabel("Pi")
plt.title("Area Method - Histogram for 10000 runs of 1e6 samples")
plt.hist(pis, bins=40)
plt.axvline(x=mean, color="r", label=f"$\\mu={mean:.6f}$")  # type: ignore
plt.axvline(x=mean + std, color="y", label=f"$\\sigma={std:.2e}$")  # type: ignore
plt.axvline(x=mean - std, color="y")  # type: ignore
plt.axvline(x=np.pi, color="k", label=f"$\\pi={np.pi:.6f}$")
plt.legend()
plt.savefig("./Latex/images/area_method_histogram2.png", dpi=300)
print("Area Method:")
print(f"{mean = }")
print(f"{std = }")


# %% MC Integration Method
import numpy as np
import matplotlib.pyplot as plt


def p(x):
    return 1


def f(x):
    return np.sqrt(1 - x**2)


def mc_integrate(n, plot=False):
    sum = 0
    estimates_n = np.array([], dtype=int)
    estimates_area = np.array([], dtype=np.float32)
    for i in range(n):
        x = np.random.random()
        sum += f(x) / p(x)
        if plot:
            if i % (int(n / 100000)) == 0 and i > 1000000:
                estimates_n = np.append(estimates_n, i+1)
                estimates_area = np.append(estimates_area, 4 * sum / (i+1))
    if plot:
        plt.xlabel("n")
        plt.title("MC Integration Method - Convergence")
        plt.ylabel("Pi Estimate")
        plt.plot(estimates_n, estimates_area, label="Estimate")
        plt.axhline(y=np.pi, color="k", label="$\\pi$")
        plt.legend()
        plt.savefig("./Latex/images/mc_integration_method_convergence2.png", dpi=300)
    return sum / n * 4


def mc_integrate_fast(n):
    x = np.random.random(n)
    return np.sum(f(x)) / n * 4

#%%
mc_integrate(int(1e8), plot=True)

#%%
pis = np.zeros(10000)
for i in range(10000):
    pis[i] = mc_integrate_fast(int(1e6))
std = np.std(pis)
mean = np.mean(pis)
plt.ylabel("n")
plt.xlabel("Pi")
plt.title("MC Integration Method - Histogram for 10000 runs of 1e6 samples")
plt.hist(pis, bins=40)
plt.axvline(x=mean, color="r", label=f"$\\mu={mean:.6f}$")  # type: ignore
plt.axvline(x=mean + std, color="y", label=f"$\\sigma={std:.2e}$")  # type: ignore
plt.axvline(x=mean - std, color="y")  # type: ignore
plt.axvline(x=np.pi, color="k", label=f"$\\pi={np.pi:.6f}$")
plt.legend()
plt.savefig("./Latex/images/mc_integration_method_histogram2.png", dpi=300)
print("MC Integration Method:")
print(f"{mean = }")
print(f"{std = }")

# %%
